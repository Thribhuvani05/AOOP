public class Main {
    public static void main(String[] args) {
        // Example usage of the StringToIntConverter
        try {
            System.out.println(StringToIntConverter.convert("123")); // Output: 123
            System.out.println(StringToIntConverter.convert("-456")); // Output: -456
            System.out.println(StringToIntConverter.convert("007")); // Output: 7
            System.out.println(StringToIntConverter.convert("")); // Throws NumberFormatException
        } catch (NumberFormatException e) {
            System.err.println(e.getMessage());
        }
    }
}
