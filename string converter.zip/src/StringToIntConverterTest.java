import org.junit.Test;
import static org.junit.Assert.*;
public class StringToIntConverterTest {
	public void testSimplePositiveNumber() {
        assertEquals(123, StringToIntConverter.convert("123"));
    }

    @Test
    public void testSimpleNegativeNumber() {
        assertEquals(-456, StringToIntConverter.convert("-456"));
    }

    @Test
    public void testNumberWithLeadingZeros() {
        assertEquals(7, StringToIntConverter.convert("007"));
    }

    @Test(expected = NumberFormatException.class)
    public void testEmptyString() {
        StringToIntConverter.convert("");
    }

    @Test(expected = NumberFormatException.class)
    public void testNonNumericCharacters() {
        StringToIntConverter.convert("abc");
    }

    @Test(expected = NumberFormatException.class)
    public void testMixedCharacters() {
        StringToIntConverter.convert("12a34");
    }


}
