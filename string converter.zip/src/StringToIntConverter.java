
public class StringToIntConverter {
	 public static int convert(String s) {
	        if (s == null || s.isEmpty()) {
	            throw new NumberFormatException("Input string is empty");
	        }
	        return Integer.parseInt(s);
	    }
}
